<template>
  <main class="min-h-dvh grid place-items-center px-4">
    <div class="w-full max-w-md py-10">
      <div class="w-full card p-6 sm:p-8 animate-pulseGlow">
        <RouterView />
      </div>
      <p class="mt-6 text-center text-xs text-text-3">
        JabuSpark MVP • Secure sign-in powered by the JabuSpark API
      </p>
    </div>
  </main>
</template>
