<script setup>
defineProps({
  label: String,
  value: [String, Number],
  hint: { type: String, default: '' }
})
</script>

<template>
  <div class="glass rounded-xl2 p-3 border border-stroke/60">
    <div class="text-xs text-text-3">{{ label }}</div>
    <div class="text-xl font-extrabold tracking-tight mt-0.5">{{ value }}</div>
    <div v-if="hint" class="text-xs text-text-2 mt-1">{{ hint }}</div>
  </div>
</template>
