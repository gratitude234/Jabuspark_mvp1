<template>
  <div class="card p-4 sm:p-5">
    <slot />
  </div>
</template>
