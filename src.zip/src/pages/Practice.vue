<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useContentStore } from '../stores/content'
import { useDataStore } from '../stores/data'
import AppCard from '../components/AppCard.vue'
import AppButton from '../components/AppButton.vue'
import { formatDuration } from '../utils/format'

const route = useRoute()
const router = useRouter()
const content = useContentStore()
const data = useDataStore()

const bankId = computed(() => String(route.params.bankId || ''))
const bank = computed(() => content.bank)
const questions = computed(() => bank.value?.questions || [])

// state
const idx = ref(0)
const reveal = ref(false)
const selected = ref(null)
const startAt = ref(Date.now())
const bankStartAt = ref(Date.now())
const busy = ref(false)
const error = ref('')

const done = ref(false)
const reviewWrong = ref(false)

// time ticker
const now = ref(Date.now())
let timer = null

const answeredIds = computed(() => data.answers?.[bankId.value]?.answeredIds || [])
const correctIds = computed(() => data.answers?.[bankId.value]?.correctIds || [])
const correctSet = computed(() => new Set(correctIds.value))
const wrongIds = computed(() => answeredIds.value.filter((id) => !correctSet.value.has(id)))

const wrongIndexOrder = computed(() => {
  const wrong = new Set(wrongIds.value)
  const out = []
  for (let i = 0; i < questions.value.length; i++) {
    const q = questions.value[i]
    if (q?.id && wrong.has(q.id)) out.push(i)
  }
  return out
})

const order = computed(() => {
  if (reviewWrong.value) return wrongIndexOrder.value
  return questions.value.map((_, i) => i)
})

const orderLen = computed(() => order.value.length || 0)

const current = computed(() => {
  if (done.value) return null
  const realIndex = order.value[idx.value]
  return questions.value[realIndex] || null
})

const answeredCount = computed(() => answeredIds.value.length)
const correctCount = computed(() => correctIds.value.length)
const totalQuestions = computed(() => questions.value.length)

const accuracyAnsweredPct = computed(() => {
  const denom = Math.max(1, answeredCount.value)
  return Math.round((correctCount.value / denom) * 100)
})

const accuracyTotalPct = computed(() => {
  const denom = Math.max(1, totalQuestions.value)
  return Math.round((correctCount.value / denom) * 100)
})

const progressPct = computed(() => {
  const total = Math.max(1, orderLen.value || 1)
  const at = done.value ? total : Math.min(total, idx.value + 1)
  return Math.round((at / total) * 100)
})

const questionTimerText = computed(() => {
  const secs = Math.max(0, Math.round((now.value - startAt.value) / 1000))
  return formatDuration(secs)
})

const totalTimerText = computed(() => {
  const secs = Math.max(0, Math.round((now.value - bankStartAt.value) / 1000))
  return formatDuration(secs)
})

const isCorrectSelection = computed(() => {
  if (!current.value || selected.value === null) return false
  return Number(selected.value) === Number(current.value.answerIndex)
})

watch(current, (q) => {
  if (!q) return
  reveal.value = false
  selected.value = null
  startAt.value = Date.now()
})

onMounted(async () => {
  error.value = ''
  await Promise.allSettled([data.fetchProgress(), content.fetchBank(bankId.value)])
  if (!content.bank) error.value = content.error || 'Bank not found'

  bankStartAt.value = Date.now()
  startAt.value = Date.now()

  timer = setInterval(() => {
    now.value = Date.now()
  }, 1000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})

function pick(i) {
  if (busy.value) return
  if (reveal.value) return
  selected.value = i
}

async function submitAnswerOnly() {
  if (!current.value) return
  if (selected.value === null) return

  busy.value = true
  error.value = ''

  try {
    const secondsSpent = Math.max(0, Math.round((Date.now() - startAt.value) / 1000))
    const res = await data.submitAnswer({
      bankId: bankId.value,
      questionId: current.value.id,
      selectedIndex: Number(selected.value),
      secondsSpent,
    })

    reveal.value = true
    return res
  } catch (e) {
    error.value = e?.message || 'Failed to submit'
  } finally {
    busy.value = false
  }
}

function goNext() {
  const total = orderLen.value
  if (total <= 0) return
  if (idx.value >= total - 1) {
    done.value = true
    return
  }
  idx.value += 1
}

async function primaryAction() {
  if (done.value) return
  if (!reveal.value) await submitAnswerOnly()
  else goNext()
}

function back() {
  if (done.value) {
    done.value = false
    idx.value = Math.max(0, orderLen.value - 1)
    return
  }
  if (idx.value > 0) idx.value -= 1
  else router.push('/dashboard')
}

async function reset() {
  if (!confirm('Reset your progress for this bank?')) return
  await data.resetBank(bankId.value)

  reviewWrong.value = false
  done.value = false
  idx.value = 0
  reveal.value = false
  selected.value = null
  bankStartAt.value = Date.now()
  startAt.value = Date.now()
}

function startWrongReview() {
  if (wrongIndexOrder.value.length === 0) return
  reviewWrong.value = true
  done.value = false
  idx.value = 0
  reveal.value = false
  selected.value = null
  startAt.value = Date.now()
}
</script>

<template>
  <div v-if="bank" class="space-y-5">
    <AppCard>
      <div class="flex items-start justify-between gap-4">
        <div class="min-w-0">
          <div class="h1 truncate">{{ bank.title }}</div>
          <p class="sub mt-2">
            {{ answeredCount }} answered • {{ correctCount }} correct
            <span class="text-text-3">•</span>
            Accuracy {{ accuracyAnsweredPct }}% (answered)
            <span class="text-text-3">•</span>
            {{ accuracyTotalPct }}% (of total)
            <span v-if="reviewWrong" class="text-text-3">•</span>
            <span v-if="reviewWrong">Reviewing wrong answers</span>
          </p>
        </div>
        <div class="flex gap-2">
          <AppButton variant="ghost" @click="reset">Reset</AppButton>
          <AppButton variant="ghost" @click="back">Back</AppButton>
        </div>
      </div>

      <div class="mt-4 h-2 rounded-full bg-white/10 overflow-hidden">
        <div class="h-full bg-accent/70" :style="{ width: progressPct + '%' }"></div>
      </div>
    </AppCard>

    <!-- Summary -->
    <AppCard v-if="done">
      <div class="h2">Session summary</div>
      <p class="sub mt-2">
        You got <span class="text-text font-bold">{{ correctCount }}</span> correct.
        <span class="text-text-3">•</span>
        Answered: <span class="text-text font-bold">{{ answeredCount }}</span> /
        <span class="text-text font-bold">{{ totalQuestions }}</span>
      </p>

      <div class="mt-2 text-sm text-text-2">
        Accuracy:
        <span class="text-text font-bold">{{ accuracyAnsweredPct }}%</span> of answered
        <span class="text-text-3">•</span>
        <span class="text-text font-bold">{{ accuracyTotalPct }}%</span> of total bank
      </div>

      <div class="mt-4 grid sm:grid-cols-3 gap-3">
        <div class="glass rounded-xl2 border border-stroke/60 p-4">
          <div class="text-xs text-text-3">Total Questions</div>
          <div class="text-lg font-extrabold mt-1">{{ totalQuestions }}</div>
        </div>
        <div class="glass rounded-xl2 border border-stroke/60 p-4">
          <div class="text-xs text-text-3">Wrong Answers</div>
          <div class="text-lg font-extrabold mt-1">{{ wrongIds.length }}</div>
        </div>
        <div class="glass rounded-xl2 border border-stroke/60 p-4">
          <div class="text-xs text-text-3">Time Spent</div>
          <div class="text-lg font-extrabold mt-1">{{ totalTimerText }}</div>
        </div>
      </div>

      <div class="mt-5 flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div class="text-sm text-text-2">
          Tip: reviewing wrong answers once improves retention more than restarting immediately.
        </div>

        <div class="flex flex-col sm:flex-row gap-2">
          <AppButton variant="ghost" :disabled="wrongIds.length === 0" @click="startWrongReview">
            Review wrong answers
          </AppButton>
          <AppButton variant="ghost" @click="reset">Restart bank</AppButton>
          <RouterLink to="/dashboard" class="btn btn-primary px-4 py-3 inline-flex justify-center">
            Back to Dashboard
          </RouterLink>
        </div>
      </div>
    </AppCard>

    <!-- Question -->
    <AppCard v-else-if="current">
      <div class="text-sm text-text-3">Question {{ idx + 1 }} of {{ orderLen }}</div>

      <div class="text-lg font-extrabold mt-2">{{ current.prompt }}</div>

      <div class="mt-4 grid gap-2">
        <button
          v-for="(opt, i) in current.options"
          :key="i"
          class="glass rounded-xl2 border border-stroke/60 px-4 py-3 text-left hover:bg-white/5 transition disabled:opacity-60 disabled:cursor-not-allowed"
          :class="[
            selected === i ? 'ring-2 ring-accent/50' : '',
            reveal && i === current.answerIndex ? 'ring-2 ring-green-400/40' : '',
            reveal && selected === i && i !== current.answerIndex ? 'ring-2 ring-danger/50' : ''
          ]"
          @click="pick(i)"
          :disabled="busy || reveal"
          type="button"
        >
          <div class="text-sm font-semibold">{{ opt }}</div>
        </button>
      </div>

      <p v-if="error" class="text-sm text-danger mt-4">{{ error }}</p>

      <div class="mt-4 flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div class="text-xs text-text-3">Time: {{ questionTimerText }}</div>

        <AppButton class="w-full sm:w-auto" :disabled="busy || selected === null" @click="primaryAction">
          <span v-if="!busy">
            <span v-if="!reveal">Check answer</span>
            <span v-else>{{ idx >= orderLen - 1 ? 'Finish' : 'Next question' }}</span>
          </span>
          <span v-else>Saving…</span>
        </AppButton>
      </div>

      <div v-if="reveal" class="mt-4 glass rounded-xl2 border border-stroke/60 p-4">
        <div class="flex items-center justify-between gap-3">
          <div class="text-sm font-bold">Explanation</div>
          <div class="text-sm font-bold" :class="isCorrectSelection ? 'text-green-400' : 'text-danger'">
            {{ isCorrectSelection ? '✅ Correct' : '❌ Not quite' }}
          </div>
        </div>
        <p class="text-sm text-text-2 mt-2">{{ current.explain }}</p>
      </div>
    </AppCard>
  </div>

  <div v-else class="card p-6">
    <div class="h1">Bank not found</div>
    <p class="sub mt-2">{{ error || 'This practice bank doesn’t exist or failed to load.' }}</p>
    <RouterLink to="/dashboard" class="btn btn-primary mt-4 inline-flex">Go back</RouterLink>
  </div>
</template>
