<template>
  <main class="min-h-dvh flex flex-col">
    <div class="flex-1">
      <RouterView />
    </div>

    <p class="px-4 pb-6 pt-2 text-center text-xs text-text-3">
      JabuSpark MVP • Secure sign-in powered by the JabuSpark API
    </p>
  </main>
</template>
