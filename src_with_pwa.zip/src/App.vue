<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from './stores/auth'
import { useDataStore } from './stores/data'
import { useCatalogStore } from './stores/catalog'
import ToastHost from './components/ToastHost.vue'

import PwaInstallBanner from './components/PwaInstallBanner.vue'
import PwaUpdateToast from './components/PwaUpdateToast.vue'
import OfflineBanner from './components/OfflineBanner.vue'
const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()
const router = useRouter()

const toast = ref(null)

function handleToast(e) {
  const d = e?.detail || {}
  if (!d?.message) return
  toast.value?.push(String(d.message), d.tone || 'ok')
}

function handleAuthExpired() {
  toast.value?.push('Session expired. Please log in again.', 'warn')
  router.push('/auth/login')
}

onMounted(async () => {
  window.addEventListener('auth:expired', handleAuthExpired)
  window.addEventListener('app:toast', handleToast)
  await auth.hydrate()
  if (auth.isAuthed) {
    // keep these light; pages can fetch deeper lists as needed
    await Promise.allSettled([catalog.bootstrap(), data.bootstrap()])
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('auth:expired', handleAuthExpired)
  window.removeEventListener('app:toast', handleToast)
})
</script>

<template>
  <div class="min-h-dvh">
    <div class="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div class="absolute -top-24 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-accent/10 blur-3xl animate-floaty"></div>
      <div class="absolute -bottom-24 -left-24 h-[520px] w-[520px] rounded-full bg-white/5 blur-3xl"></div>
      <div class="absolute -top-40 -right-40 h-[640px] w-[640px] rounded-full bg-white/4 blur-3xl"></div>
    </div>

    <RouterView />

    <OfflineBanner />
    <PwaUpdateToast />
    <PwaInstallBanner />

    <ToastHost ref="toast" />
  </div>
</template>
