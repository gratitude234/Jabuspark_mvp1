<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import LogoMark from '../components/LogoMark.vue'

const route = useRoute()
const auth = useAuthStore()

const isMatch = (prefix) => {
  const p = route.path || ''
  return p === prefix || p.startsWith(prefix + '/') || p.startsWith(prefix)
}

const title = computed(() => route.meta?.title || 'JabuSpark')

const navItems = computed(() => [
  { label: 'Home', to: '/dashboard', match: () => isMatch('/dashboard') },
  { label: 'Practice', to: '/practice', match: () => isMatch('/practice') },
  { label: 'Past Questions', to: '/past-questions', match: () => isMatch('/past-questions') },
  { label: 'Materials', to: '/materials', match: () => isMatch('/materials') },
  { label: 'Saved', to: '/saved', match: () => isMatch('/saved') },
])

const navBtnClass = (active) => {
  return [
    'btn btn-ghost',
    'flex-1 py-3',
    active ? 'bg-white/8 ring-1 ring-white/10 text-text' : 'text-text-2 hover:text-text',
  ].join(' ')
}

const desktopNavClass = (active) => {
  return [
    'btn btn-ghost',
    'px-3 py-2 text-sm',
    active ? 'bg-white/8 ring-1 ring-white/10 text-text' : 'text-text-2 hover:text-text',
  ].join(' ')
}
</script>

<template>
  <!-- Bottom padding accounts for fixed mobile nav + iOS safe-area -->
  <div class="min-h-dvh pb-[calc(88px+env(safe-area-inset-bottom))] sm:pb-0">
    <!-- Top bar -->
    <header class="sticky top-0 z-40 border-b border-white/10 bg-surface/70 backdrop-blur-xl">
      <div class="container-app h-16 flex items-center justify-between gap-3">
        <!-- ✅ Responsive logo placement -->
        <RouterLink
          to="/dashboard"
          class="hover:opacity-90 flex items-center gap-2"
          aria-label="Go to dashboard"
        >
          <!-- auto = mark on mobile, lockup on desktop -->
          <!-- Explicit heights to avoid Tailwind dynamic class generation issues -->
          <LogoMark variant="auto" :mobile="9" :desktop="10" alt="JabuSpark" />
        </RouterLink>

        <!-- Desktop nav -->
        <nav class="hidden sm:flex items-center gap-2" aria-label="Primary">
          <RouterLink
            v-for="item in navItems"
            :key="item.to"
            :to="item.to"
            :class="desktopNavClass(item.match())"
            :aria-current="item.match() ? 'page' : undefined"
          >
            {{ item.label }}
          </RouterLink>
        </nav>

        <div class="flex items-center gap-2">
          <div class="hidden sm:block text-sm text-text-2">{{ title }}</div>

          <RouterLink
            to="/profile"
            class="chip hover:bg-white/5"
            :class="isMatch('/profile') ? 'ring-1 ring-white/10 bg-white/5' : ''"
            :aria-current="isMatch('/profile') ? 'page' : undefined"
          >
            <span class="h-2 w-2 rounded-full bg-accent"></span>
            <span class="max-w-[160px] truncate">{{ auth.user?.fullName || 'Student' }}</span>
          </RouterLink>
        </div>
      </div>
    </header>

    <!-- Main -->
    <div class="container-app py-6">
      <RouterView />
    </div>

    <!-- Mobile bottom nav -->
    <nav
      class="sm:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 bg-surface/80 backdrop-blur-xl pb-[env(safe-area-inset-bottom)]"
      aria-label="Primary"
    >
      <div class="container-app h-[76px] flex items-center justify-between gap-2">
        <RouterLink
          v-for="item in navItems"
          :key="item.to"
          :to="item.to"
          :class="navBtnClass(item.match())"
          :aria-current="item.match() ? 'page' : undefined"
        >
          {{ item.label }}
        </RouterLink>
      </div>
    </nav>
  </div>
</template>
