export const pastQuestions = [
  {
    id: 'pq_gst211_2324_harm',
    courseId: 'gst211',
    session: '2023/2024',
    semester: 'Harmattan',
    title: 'GST 211 Past Questions – 2023/2024 (Harmattan)',
    fileUrl: '/sample/pq_demo.pdf',
    uploadedAt: '2025-12-01'
  }
]
