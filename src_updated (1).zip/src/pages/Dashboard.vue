<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useDataStore } from '../stores/data'
import { useCatalogStore } from '../stores/catalog'
import { useContentStore } from '../stores/content'
import AppCard from '../components/AppCard.vue'
import StatPill from '../components/StatPill.vue'
import AppButton from '../components/AppButton.vue'
import { formatDuration } from '../utils/format'

const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()
const content = useContentStore()

const selectedCourseId = ref(auth.user?.profile?.courseIds?.[0] || null)

const profile = computed(() => auth.user?.profile || {})
const fac = computed(() => (catalog.faculties || []).find(f => f.id === profile.value.facultyId))
const dept = computed(() => (catalog.departments || []).find(d => d.id === profile.value.departmentId))

const myCourses = computed(() =>
  (catalog.courses || []).filter(c => (profile.value.courseIds || []).includes(c.id))
)

const courseOptions = computed(() => myCourses.value.map(c => ({ value: c.id, label: `${c.code} (${c.level})` })))

const banksForSelected = computed(() =>
  (content.banks || []).filter(b => !selectedCourseId.value || b.courseId === selectedCourseId.value)
)

const quickBank = computed(() => banksForSelected.value[0] || null)

watch(selectedCourseId, async (cid) => {
  if (!cid) return
  await content.fetchBanks({ courseId: cid })
}, { immediate: false })

onMounted(async () => {
  // Ensure we have labels even if user came from onboarding (filtered courses)
  await Promise.allSettled([
    catalog.fetchFaculties(),
    catalog.fetchDepartments(),
    catalog.fetchCourses(),
  ])

  if (auth.isAuthed) await data.fetchProgress()

  if (selectedCourseId.value) {
    await content.fetchBanks({ courseId: selectedCourseId.value })
  } else if (profile.value.courseIds?.length) {
    selectedCourseId.value = profile.value.courseIds[0]
    await content.fetchBanks({ courseId: selectedCourseId.value })
  }
})

function savedCount() {
  const s = data.progress.saved || {}
  return (s.pastQuestions?.length || 0) + (s.materials?.length || 0) + (s.questions?.length || 0)
}
</script>

<template>
  <div class="space-y-5">
    <AppCard>
      <div class="flex items-start justify-between gap-4">
        <div>
          <div class="h1">Hi, {{ auth.user?.fullName || 'Student' }} 👋</div>
          <p class="sub mt-2">
            <span v-if="dept">{{ dept.name }}</span>
            <span v-else class="text-text-3">Complete onboarding to personalize your dashboard.</span>
            <span v-if="fac"> • {{ fac.name }}</span>
          </p>
        </div>

        <RouterLink to="/profile" class="btn btn-ghost hidden sm:inline-flex">Profile</RouterLink>
      </div>

      <div class="mt-5 flex flex-wrap gap-2">
        <StatPill label="Streak" :value="data.progress.streak || 0" />
        <StatPill label="Accuracy" :value="(data.progress.accuracy || 0) + '%'" />
        <StatPill label="Answered" :value="data.progress.totalAnswered || 0" />
        <StatPill label="Study time" :value="formatDuration(data.progress.studySeconds || 0)" />
      </div>
    </AppCard>

    <AppCard>
      <div class="flex items-center justify-between gap-3">
        <div>
          <div class="h2">Practice banks</div>
          <p class="sub mt-1">Pick a course and start drilling questions.</p>
        </div>
        <RouterLink to="/materials" class="btn btn-ghost">Materials</RouterLink>
      </div>

      <div class="mt-4 grid gap-3 sm:grid-cols-3">
        <div class="sm:col-span-1 glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-sm font-bold">Course</div>
          <p class="text-xs text-text-3 mt-1">Choose what to load.</p>

          <select
            class="select appearance-none mt-3"
            :value="selectedCourseId ?? ''"
            @change="selectedCourseId = $event.target.value || null"
          >
            <option value="">All courses</option>
            <option v-for="o in courseOptions" :key="o.value" :value="o.value">{{ o.label }}</option>
          </select>

          <p v-if="content.loading.banks" class="text-xs text-text-3 mt-3">Loading banks…</p>
          <p v-else class="text-xs text-text-3 mt-3">{{ banksForSelected.length }} banks available</p>
        </div>

        <div class="sm:col-span-2 glass rounded-xl2 p-4 border border-stroke/60">
          <div class="flex items-center justify-between gap-3">
            <div>
              <div class="text-sm font-bold">Quick start</div>
              <p class="text-xs text-text-3 mt-1">Continue practicing from your latest bank.</p>
            </div>
            <RouterLink v-if="quickBank" :to="`/practice/${quickBank.id}`" class="btn btn-primary">Continue</RouterLink>
            <RouterLink v-else to="/onboarding" class="btn btn-primary">Set up</RouterLink>
          </div>

          <div v-if="quickBank" class="mt-4">
            <div class="text-base font-extrabold">{{ quickBank.title }}</div>
            <div class="text-sm text-text-2 mt-1">
              {{ quickBank.questionCount }} questions • Mode: {{ quickBank.mode }}
            </div>
          </div>

          <div v-else class="mt-4 text-sm text-text-2">
            No banks found yet for your selection.
          </div>

          <div class="divider my-5"></div>

          <div class="grid gap-3 sm:grid-cols-4">
            <div class="glass rounded-xl2 p-4 border border-stroke/60">
              <div class="text-xs text-text-3">Saved</div>
              <div class="text-2xl font-extrabold mt-1">{{ savedCount() }}</div>
            </div>
            <div class="glass rounded-xl2 p-4 border border-stroke/60">
              <div class="text-xs text-text-3">PastQ</div>
              <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.pastQuestions?.length || 0 }}</div>
            </div>
            <div class="glass rounded-xl2 p-4 border border-stroke/60">
              <div class="text-xs text-text-3">Materials</div>
              <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.materials?.length || 0 }}</div>
            </div>
            <div class="glass rounded-xl2 p-4 border border-stroke/60">
              <div class="text-xs text-text-3">Questions</div>
              <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.questions?.length || 0 }}</div>
            </div>
          </div>
        </div>
      </div>
    </AppCard>

    <AppCard>
      <div class="flex items-center justify-between">
        <div>
          <div class="h2">Explore</div>
          <p class="sub mt-1">Past questions and lecture materials per course.</p>
        </div>
        <div class="flex gap-2">
          <RouterLink to="/past-questions" class="btn btn-ghost">Past Questions</RouterLink>
          <RouterLink to="/materials" class="btn btn-ghost">Materials</RouterLink>
        </div>
      </div>
    </AppCard>
  </div>
</template>
