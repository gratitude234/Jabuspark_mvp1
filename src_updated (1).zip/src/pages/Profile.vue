<script setup>
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { useDataStore } from '../stores/data'
import { useCatalogStore } from '../stores/catalog'
import AppCard from '../components/AppCard.vue'
import AppButton from '../components/AppButton.vue'
import { formatDuration } from '../utils/format'

const router = useRouter()
const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()

const profile = computed(() => auth.user?.profile || {})
const fac = computed(() => (catalog.faculties || []).find(f => f.id === profile.value.facultyId))
const dept = computed(() => (catalog.departments || []).find(d => d.id === profile.value.departmentId))
const myCourses = computed(() => (catalog.courses || []).filter(c => (profile.value.courseIds || []).includes(c.id)))

onMounted(async () => {
  await Promise.allSettled([
    catalog.fetchFaculties(),
    catalog.fetchDepartments(),
    catalog.fetchCourses(),
    data.fetchProgress()
  ])
})

async function logout() {
  await auth.logout()
  router.push('/auth/login')
}
</script>

<template>
  <div class="space-y-5">
    <AppCard>
      <div class="h1">Profile</div>
      <p class="sub mt-2">Your study setup and progress.</p>

      <div class="divider my-5"></div>

      <div class="grid gap-3 sm:grid-cols-2">
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Name</div>
          <div class="text-lg font-extrabold mt-1">{{ auth.user?.fullName }}</div>
          <div class="text-sm text-text-2 mt-1">{{ auth.user?.email }}</div>
        </div>

        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Department</div>
          <div class="text-lg font-extrabold mt-1">{{ dept?.name || '—' }}</div>
          <div class="text-sm text-text-2 mt-1">{{ fac?.name || '' }}</div>
        </div>
      </div>

      <div class="divider my-5"></div>

      <div class="h2">Courses</div>
      <div class="mt-3 grid gap-2 sm:grid-cols-2">
        <div v-for="c in myCourses" :key="c.id" class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-sm font-bold">{{ c.code }}</div>
          <div class="text-xs text-text-3 mt-1">{{ c.title }}</div>
        </div>
        <div v-if="myCourses.length === 0" class="text-sm text-text-2">No courses set.</div>
      </div>

      <div class="divider my-5"></div>

      <div class="h2">Progress</div>
      <div class="mt-4 grid gap-3 sm:grid-cols-4">
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Streak</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.streak }}</div>
        </div>
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Accuracy</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.accuracy }}%</div>
        </div>
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Answered</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.totalAnswered }}</div>
        </div>
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Study</div>
          <div class="text-2xl font-extrabold mt-1">{{ formatDuration(data.progress.studySeconds) }}</div>
        </div>
      </div>

      <div class="divider my-5"></div>

      <div class="h2">Saved</div>
      <div class="mt-4 grid gap-3 sm:grid-cols-3">
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Past Questions</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.pastQuestions.length }}</div>
        </div>
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Materials</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.materials.length }}</div>
        </div>
        <div class="glass rounded-xl2 p-4 border border-stroke/60">
          <div class="text-xs text-text-3">Questions</div>
          <div class="text-2xl font-extrabold mt-1">{{ data.progress.saved.questions.length }}</div>
        </div>
      </div>

      <div class="divider my-5"></div>

      <div class="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <RouterLink to="/onboarding" class="btn btn-ghost w-full sm:w-auto">Edit onboarding</RouterLink>
        <AppButton variant="danger" class="w-full sm:w-auto" @click="logout">Log out</AppButton>
      </div>
    </AppCard>
  </div>
</template>
