<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useDataStore } from '../stores/data'
import { useCatalogStore } from '../stores/catalog'
import { useContentStore } from '../stores/content'
import AppCard from '../components/AppCard.vue'
import AppButton from '../components/AppButton.vue'
import PdfModal from '../components/PdfModal.vue'

const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()
const content = useContentStore()

const selectedCourseId = ref(auth.user?.profile?.courseIds?.[0] || null)
const openItem = ref(null)

const myCourses = computed(() =>
  (catalog.courses || []).filter(c => (auth.user?.profile?.courseIds || []).includes(c.id))
)
const courseOptions = computed(() => myCourses.value.map(c => ({ value: c.id, label: `${c.code} (${c.level})` })))

const items = computed(() =>
  (content.pastQuestions || []).filter(pq => !selectedCourseId.value || pq.courseId === selectedCourseId.value)
)

watch(selectedCourseId, async (cid) => {
  await content.fetchPastQuestions({ courseId: cid || '' })
})

onMounted(async () => {
  await Promise.allSettled([catalog.fetchCourses(), data.fetchProgress()])
  await content.fetchPastQuestions({ courseId: selectedCourseId.value || '' })
})

async function toggleSave(pq) {
  await data.toggleSave('pastQuestions', pq.id)
}
</script>

<template>
  <div class="space-y-5">
    <AppCard>
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div class="h1">Past Questions</div>
          <p class="sub mt-1">Filter by course and preview PDFs fullscreen.</p>
        </div>

        <div class="w-full sm:w-[320px]">
          <select
            class="select appearance-none"
            :value="selectedCourseId ?? ''"
            @change="selectedCourseId = $event.target.value || null"
          >
            <option value="">All my courses</option>
            <option v-for="o in courseOptions" :key="o.value" :value="o.value">{{ o.label }}</option>
          </select>
        </div>
      </div>
    </AppCard>

    <AppCard v-if="content.loading.pastQuestions">
      <div class="muted">Loading past questions…</div>
    </AppCard>

    <AppCard v-else-if="items.length === 0">
      <div class="muted">No past questions found for this selection.</div>
    </AppCard>

    <div v-else class="grid gap-3">
      <AppCard v-for="pq in items" :key="pq.id" class="p-5">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="text-base font-extrabold truncate">{{ pq.title }}</div>
            <div class="text-sm text-text-2 mt-1">
              {{ pq.session }} • {{ pq.semester }} • {{ pq.uploadedAt }}
            </div>
          </div>

          <div class="flex gap-2">
            <button class="btn btn-ghost px-3 py-2" @click="toggleSave(pq)">
              {{ data.isSaved('pastQuestions', pq.id) ? 'Saved' : 'Save' }}
            </button>
            <button class="btn btn-primary px-3 py-2" @click="openItem = pq">Preview</button>
            <a class="btn btn-ghost px-3 py-2" :href="pq.fileUrl" target="_blank" rel="noreferrer">Open</a>
          </div>
        </div>
      </AppCard>
    </div>

    <PdfModal
      :open="!!openItem"
      :title="openItem?.title || 'Past question'"
      :url="openItem?.fileUrl || ''"
      @close="openItem = null"
    />
  </div>
</template>
