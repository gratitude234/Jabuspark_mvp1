<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useDataStore } from '../stores/data'
import { useCatalogStore } from '../stores/catalog'
import { useContentStore } from '../stores/content'
import AppCard from '../components/AppCard.vue'
import AppButton from '../components/AppButton.vue'

const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()
const content = useContentStore()

const profile = computed(() => auth.user?.profile || {})
const myCourseIds = computed(() => profile.value.courseIds || [])
const hasProfileCourses = computed(() => myCourseIds.value.length > 0)

const selectedCourseId = ref(myCourseIds.value[0] || '')

const myCourses = computed(() =>
  (catalog.courses || []).filter(c => myCourseIds.value.includes(c.id))
)

const courseOptions = computed(() => [
  { value: '', label: 'All my courses' },
  ...myCourses.value.map(c => ({ value: c.id, label: `${c.code} (${c.level})` })),
])

const banks = computed(() => content.banks || [])

const filteredBanks = computed(() => {
  const cid = selectedCourseId.value || ''
  if (!cid) return banks.value
  return banks.value.filter(b => b.courseId === cid)
})

const bankStats = (bankId) => {
  const s = data.answers?.[bankId] || {}
  const answered = (s.answeredIds || []).length
  const correct = (s.correctIds || []).length
  const total = Number(s.totalQuestions || 0) || null // optional if backend sends it later
  return { answered, correct, total }
}

const accuracyPct = (answered, correct) => {
  const denom = Math.max(1, answered)
  return Math.round((correct / denom) * 100)
}

watch(selectedCourseId, async (cid) => {
  // refresh banks per course for better performance
  await content.fetchBanks({ courseId: cid || '' })
})

onMounted(async () => {
  // Ensure labels + courses for filter
  await Promise.allSettled([
    catalog.fetchFaculties?.(),
    catalog.fetchDepartments?.(),
    catalog.fetchCourses?.(),
  ])

  if (auth.isAuthed) await data.fetchProgress()

  // Load banks (for selected course if any)
  await content.fetchBanks({ courseId: selectedCourseId.value || '' })
})
</script>

<template>
  <div class="space-y-5">
    <AppCard>
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div class="h1">Practice</div>
          <p class="sub mt-1">Pick a bank and start drilling. Your progress saves automatically.</p>
        </div>

        <div class="flex gap-2">
          <RouterLink to="/saved" class="btn btn-ghost">Saved</RouterLink>
          <RouterLink to="/dashboard" class="btn btn-ghost">Dashboard</RouterLink>
        </div>
      </div>
    </AppCard>

    <AppCard v-if="!hasProfileCourses">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="min-w-0">
          <div class="h2">Set up your courses</div>
          <p class="sub mt-1">Add your department and courses so we can show the right practice banks.</p>
        </div>
        <RouterLink to="/onboarding" class="btn btn-primary px-4 py-3">
          Set up courses
        </RouterLink>
      </div>
    </AppCard>

    <AppCard v-else>
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div class="text-sm font-bold">Filter by course</div>
          <p class="text-xs text-text-3 mt-1">Shows banks for your selected course.</p>
        </div>

        <select
          class="select appearance-none sm:min-w-[260px]"
          :value="selectedCourseId"
          @change="selectedCourseId = $event.target.value"
        >
          <option v-for="o in courseOptions" :key="o.value" :value="o.value">{{ o.label }}</option>
        </select>
      </div>
    </AppCard>

    <AppCard v-if="content.loading.banks">
      <div class="text-sm text-text-2">Loading practice banks…</div>
    </AppCard>

    <AppCard v-else-if="filteredBanks.length === 0">
      <div class="h2">No banks found</div>
      <p class="sub mt-1">Try another course filter, or check back later.</p>
      <div class="mt-4 flex gap-2">
        <RouterLink to="/dashboard" class="btn btn-primary px-4 py-3">Back to Dashboard</RouterLink>
        <RouterLink to="/materials" class="btn btn-ghost px-4 py-3">Study Materials</RouterLink>
      </div>
    </AppCard>

    <div v-else class="grid gap-3">
      <AppCard v-for="b in filteredBanks" :key="b.id" class="p-5">
        <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div class="min-w-0">
            <div class="text-base font-extrabold">{{ b.title }}</div>
            <div class="text-sm text-text-2 mt-1">
              {{ b.questionCount }} questions
              <span class="text-text-3">•</span>
              Mode: {{ b.mode }}
            </div>

            <div class="mt-3 flex flex-wrap gap-2 text-xs text-text-2">
              <span class="chip">
                Answered: {{ bankStats(b.id).answered }}
              </span>
              <span class="chip">
                Correct: {{ bankStats(b.id).correct }}
              </span>
              <span class="chip">
                Accuracy: {{ accuracyPct(bankStats(b.id).answered, bankStats(b.id).correct) }}%
              </span>
            </div>
          </div>

          <div class="flex gap-2 sm:pt-1">
            <RouterLink :to="`/practice/${b.id}`" class="btn btn-primary px-4 py-3">
              Start
            </RouterLink>
            <AppButton variant="ghost" class="px-4 py-3" @click="data.resetBank(b.id)">
              Reset
            </AppButton>
          </div>
        </div>
      </AppCard>
    </div>
  </div>
</template>
