<script setup>
import { computed, onMounted, ref } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useDataStore } from '../stores/data'
import { useCatalogStore } from '../stores/catalog'
import { useContentStore } from '../stores/content'
import AppCard from '../components/AppCard.vue'
import AppButton from '../components/AppButton.vue'
import PdfModal from '../components/PdfModal.vue'

const auth = useAuthStore()
const data = useDataStore()
const catalog = useCatalogStore()
const content = useContentStore()

const tab = ref('pastQuestions') // 'pastQuestions' | 'materials'
const openItem = ref(null)

const profile = computed(() => auth.user?.profile || {})
const myCourseIds = computed(() => profile.value.courseIds || [])
const hasProfileCourses = computed(() => myCourseIds.value.length > 0)

const saved = computed(() => data.progress?.saved || { pastQuestions: [], materials: [], questions: [] })
const savedPQIds = computed(() => saved.value.pastQuestions || [])
const savedMatIds = computed(() => saved.value.materials || [])

const pastQuestionsAll = computed(() => content.pastQuestions || [])
const materialsAll = computed(() => content.materials || [])

const courseLabel = (courseId) => {
  const c = (catalog.courses || []).find(x => x.id === courseId)
  if (!c) return ''
  return `${c.code}${c.level ? ` (${c.level})` : ''}`
}

const savedPastQuestions = computed(() => {
  const ids = new Set(savedPQIds.value)
  const mine = new Set(myCourseIds.value)
  return pastQuestionsAll.value
    .filter(pq => ids.has(pq.id))
    .filter(pq => !hasProfileCourses.value || mine.has(pq.courseId))
})

const savedMaterials = computed(() => {
  const ids = new Set(savedMatIds.value)
  const mine = new Set(myCourseIds.value)
  return materialsAll.value
    .filter(m => ids.has(m.id))
    .filter(m => !hasProfileCourses.value || mine.has(m.courseId))
})

const activeItems = computed(() => (tab.value === 'pastQuestions' ? savedPastQuestions.value : savedMaterials.value))
const pqCount = computed(() => savedPastQuestions.value.length)
const matCount = computed(() => savedMaterials.value.length)

const tabBtnClass = (active) => {
  return [
    'btn btn-ghost px-3 py-2',
    active ? 'bg-white/8 ring-1 ring-white/10 text-text' : 'text-text-2 hover:text-text',
  ].join(' ')
}

async function toggleSave(kind, id) {
  await data.toggleSave(kind, id)
}

function fileUrlOf(item) {
  return item?.fileUrl || item?.url || item?.pdfUrl || ''
}

onMounted(async () => {
  await Promise.allSettled([
    catalog.fetchCourses?.(),
    data.fetchProgress?.(),
    content.fetchPastQuestions ? content.fetchPastQuestions({ courseId: '' }) : null,
    content.fetchMaterials ? content.fetchMaterials({ courseId: '' }) : null,
  ])
})
</script>

<template>
  <div class="space-y-5">
    <AppCard>
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div class="h1">Saved</div>
          <p class="sub mt-1">Your bookmarked past questions and materials for quick access.</p>
        </div>

        <div class="flex items-center gap-2">
          <button type="button" :class="tabBtnClass(tab === 'pastQuestions')" @click="tab = 'pastQuestions'">
            Past Questions <span class="ml-2 text-xs text-text-2">({{ pqCount }})</span>
          </button>
          <button type="button" :class="tabBtnClass(tab === 'materials')" @click="tab = 'materials'">
            Materials <span class="ml-2 text-xs text-text-2">({{ matCount }})</span>
          </button>
        </div>
      </div>
    </AppCard>

    <AppCard v-if="!hasProfileCourses">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="min-w-0">
          <div class="h2">Set up your courses to see saved items</div>
          <p class="sub mt-1">Add your department, level, and courses. You can edit anytime.</p>
        </div>
        <RouterLink to="/onboarding" class="btn btn-primary px-4 py-3">
          Set up courses
        </RouterLink>
      </div>
    </AppCard>

    <AppCard v-else-if="activeItems.length === 0">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div class="h2">Nothing saved yet</div>
          <p class="sub mt-1">
            Save {{ tab === 'pastQuestions' ? 'past questions' : 'materials' }} to access them faster later.
          </p>
        </div>
        <RouterLink :to="tab === 'pastQuestions' ? '/past-questions' : '/materials'" class="btn btn-primary px-4 py-3">
          {{ tab === 'pastQuestions' ? 'Browse Past Questions' : 'Browse Materials' }}
        </RouterLink>
      </div>
    </AppCard>

    <div v-else class="grid gap-3">
      <template v-if="tab === 'pastQuestions'">
        <AppCard v-for="pq in savedPastQuestions" :key="pq.id" class="p-5">
          <div class="flex items-start justify-between gap-3">
            <div class="min-w-0">
              <div class="text-base font-extrabold truncate">{{ pq.title }}</div>
              <div class="text-sm text-text-2 mt-1">
                <span v-if="pq.courseId">{{ courseLabel(pq.courseId) }}</span>
                <span v-if="pq.courseId"> • </span>
                <span v-if="pq.session">{{ pq.session }}</span>
                <span v-if="pq.semester"> • {{ pq.semester }}</span>
              </div>
            </div>

            <div class="flex gap-2">
              <AppButton variant="ghost" class="px-3 py-2" @click="toggleSave('pastQuestions', pq.id)">
                Remove
              </AppButton>
              <AppButton variant="primary" class="px-3 py-2" @click="openItem = pq">
                Preview
              </AppButton>
              <a class="btn btn-ghost px-3 py-2" :href="fileUrlOf(pq)" target="_blank" rel="noreferrer">
                Open
              </a>
            </div>
          </div>
        </AppCard>
      </template>

      <template v-else>
        <AppCard v-for="m in savedMaterials" :key="m.id" class="p-5">
          <div class="flex items-start justify-between gap-3">
            <div class="min-w-0">
              <div class="text-base font-extrabold truncate">{{ m.title }}</div>
              <div class="text-sm text-text-2 mt-1">
                <span v-if="m.courseId">{{ courseLabel(m.courseId) }}</span>
                <span v-if="m.courseId"> • </span>
                <span v-if="m.type">{{ m.type }}</span>
                <span v-if="m.tags?.length"> • {{ m.tags.join(', ') }}</span>
              </div>
            </div>

            <div class="flex gap-2">
              <AppButton variant="ghost" class="px-3 py-2" @click="toggleSave('materials', m.id)">
                Remove
              </AppButton>
              <AppButton variant="primary" class="px-3 py-2" @click="openItem = m">
                Preview
              </AppButton>
              <a class="btn btn-ghost px-3 py-2" :href="fileUrlOf(m)" target="_blank" rel="noreferrer">
                Open
              </a>
            </div>
          </div>
        </AppCard>
      </template>
    </div>

    <PdfModal
      :open="!!openItem"
      :title="openItem?.title || 'Saved item'"
      :url="fileUrlOf(openItem)"
      @close="openItem = null"
    />
  </div>
</template>
