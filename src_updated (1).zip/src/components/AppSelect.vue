<script setup>
defineProps({
  modelValue: { type: [String, Number, null], default: null },
  options: { type: Array, default: () => [] },
  placeholder: { type: String, default: 'Select…' }
})
defineEmits(['update:modelValue'])
</script>

<template>
  <div class="relative">
    <select
      class="select appearance-none"
      :value="modelValue ?? ''"
      @change="$emit('update:modelValue', $event.target.value || null)"
    >
      <option value="">{{ placeholder }}</option>
      <option v-for="o in options" :key="o.value" :value="o.value">{{ o.label }}</option>
    </select>
    <div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-text-3">▾</div>
  </div>
</template>
