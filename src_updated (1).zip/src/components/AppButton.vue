<script setup>
defineProps({
  variant: { type: String, default: 'primary' },
  as: { type: String, default: 'button' },
  disabled: { type: Boolean, default: false }
})
</script>

<template>
  <component
    :is="as"
    class="btn"
    :class="variant === 'primary' ? 'btn-primary' : variant === 'danger' ? 'btn-danger' : 'btn-ghost'"
    :disabled="disabled"
  >
    <slot />
  </component>
</template>

<style scoped>
button:disabled { opacity: 0.55; cursor: not-allowed; }
</style>
