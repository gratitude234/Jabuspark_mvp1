<script setup>
import { ref } from 'vue'

const toasts = ref([])

function push(message, tone = 'ok') {
  const id = crypto.randomUUID()
  toasts.value.unshift({ id, message, tone })
  setTimeout(() => {
    toasts.value = toasts.value.filter(t => t.id !== id)
  }, 2600)
}

defineExpose({ push })
</script>

<template>
  <div class="fixed right-4 top-4 z-50 w-[min(360px,calc(100vw-2rem))] space-y-2">
    <div v-for="t in toasts" :key="t.id" class="card px-4 py-3">
      <div class="text-sm font-semibold"
        :class="t.tone === 'danger' ? 'text-danger' : t.tone === 'warn' ? 'text-warn' : 'text-text'"
      >
        {{ t.message }}
      </div>
    </div>
  </div>
</template>
